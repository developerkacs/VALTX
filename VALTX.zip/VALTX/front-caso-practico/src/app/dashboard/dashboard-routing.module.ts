import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {DashboardComponent} from "./dashboard.component";
import {InicioComponent} from "./inicio/inicio.component";
import {ProductoComponent} from "./producto/producto.component";
import {UsuarioComponent} from "./usuario/usuario.component";
import {SucursalComponent} from "./sucursal/sucursal.component";
import {CrearSucursalComponent} from "./sucursal/crear-sucursal/crear-sucursal.component";
import {EditarSucursalComponent} from "./sucursal/editar-sucursal/editar-sucursal.component";
import {CrearProductoComponent} from "./producto/crear-producto/crear-producto.component";
import {EditarProductoComponent} from "./producto/editar-producto/editar-producto.component";
import {CrearUsuarioComponent} from "./usuario/crear-usuario/crear-usuario.component";
import {EditarUsuarioComponent} from "./usuario/editar-usuario/editar-usuario.component";


const routes: Routes = [
  { path: '', component: DashboardComponent,
    children: [
        { path: '', component: InicioComponent },
        { path: 'sucursal', component: SucursalComponent },
        { path: 'crear-sucursal', component: CrearSucursalComponent },
        { path: 'editar-sucursal/:id', component: EditarSucursalComponent },
        { path: 'producto', component: ProductoComponent },
        { path: 'crear-producto', component: CrearProductoComponent },
        { path: 'editar-producto/:id', component: EditarProductoComponent },
        { path: 'usuario', component: UsuarioComponent },
        { path: 'crear-usuario', component: CrearUsuarioComponent },
        { path: 'editar-usuario/:id', component: EditarUsuarioComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
