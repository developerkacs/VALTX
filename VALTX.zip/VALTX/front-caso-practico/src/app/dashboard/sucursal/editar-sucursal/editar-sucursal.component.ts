import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Sucursal} from "../../../interfaces/sucursal";
import {SucursalService} from "../../../services/sucursal.service";

@Component({
  selector: 'app-editar-sucursal',
  templateUrl: './editar-sucursal.component.html',
  styleUrls: ['./editar-sucursal.component.scss']
})
export class EditarSucursalComponent implements OnInit {
  form: FormGroup;
  constructor(private fb: FormBuilder,private sucService:SucursalService,private router:Router,private rutaActiva: ActivatedRoute) {
    this.form = this.fb.group({
      codSucursal:[],
      nombre:['',Validators.required]
    })
  }

  ngOnInit(): void {
    this.sucService.getSucursal(this.rutaActiva.snapshot.params.id).subscribe(resp => {
      this.form.patchValue(resp.message);
    });
  }
  update(){

    const suc: Sucursal =  {
      codSucursal: this.form.value.codSucursal,
      nombre: this.form.value.nombre
    };
    this.sucService.edit(suc);
    this.router.navigate(['dashboard/sucursal']);
  }

}
