import { Component, OnInit } from '@angular/core';
import {SucursalService} from "../../services/sucursal.service";
import {Sucursal} from "../../interfaces/sucursal";
import {Router} from "@angular/router";


@Component({
  selector: 'app-sucursal',
  templateUrl: './sucursal.component.html',
  styleUrls: ['./sucursal.component.scss']
})
export class SucursalComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name','acciones'];
  listSucursal: Sucursal[] = [];

  totalRecords: number = 0;
  p = 1;
  psize = 2;
  constructor(private sucService:SucursalService,private router: Router) {

  }

  ngOnInit(): void {
    this.getPage(this.p);
  }
  getPage(page: number) {
    this.loadData(page);
  }

  loadData(page: number) {
    //const pageSize = this.psize;
    const pageSize = 30;
    const pageNum = (page - 1) ;
    return this.sucService.list(pageNum, pageSize, '').subscribe((rpt) => {
      this.listSucursal = rpt.data;
      this.totalRecords = rpt.total;
      this.p = page;
    });
  }

  delete(id:string){
    this.sucService.delete(id);
    this.getPage(this.p);
  }

  editar(id:string){
    this.router.navigate(['dashboard/editar-sucursal/'+id])
  }

}
