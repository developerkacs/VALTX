import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Sucursal} from "../../../interfaces/sucursal";
import {SucursalService} from "../../../services/sucursal.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-crear-sucursal',
  templateUrl: './crear-sucursal.component.html',
  styleUrls: ['./crear-sucursal.component.scss']
})

export class CrearSucursalComponent implements OnInit {
  form: FormGroup;

  constructor(private fb: FormBuilder,private sucService:SucursalService,private router:Router) {
    this.form = this.fb.group({
      codSucursal:[],
      nombre:['',Validators.required]
    })
  }

  ngOnInit(): void {
  }

  agregar(){

     const suc: Sucursal =  {
      codSucursal: this.form.value.codSucursal,
      nombre: this.form.value.nombre
    };
    this.sucService.save(suc);
    this.router.navigate(['dashboard/sucursal']);
  }
}
