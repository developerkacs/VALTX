import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {ProductoService} from "../../../services/producto.service";
import {Producto} from "../../../interfaces/producto";

@Component({
  selector: 'app-crear-producto',
  templateUrl: './crear-producto.component.html',
  styleUrls: ['./crear-producto.component.scss']
})
export class CrearProductoComponent implements OnInit {
  form: FormGroup;


  constructor(private fb: FormBuilder,private prodService:ProductoService,private router:Router) {
    this.form = this.fb.group({
      codProducto:[],
      nombre:['',Validators.required],
      precio:['',Validators.required]
    })
  }

  ngOnInit(): void {
  }

  agregar(){

    const prod: Producto =  {
      codProducto: this.form.value.codProducto,
      nombre: this.form.value.nombre,
      precio: this.form.value.precio
    };
    this.prodService.save(prod);
    this.router.navigate(['dashboard/producto']);
  }

}
