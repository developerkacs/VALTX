import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {ProductoService} from "../../../services/producto.service";
import {Producto} from "../../../interfaces/producto";

@Component({
  selector: 'app-editar-producto',
  templateUrl: './editar-producto.component.html',
  styleUrls: ['./editar-producto.component.scss']
})
export class EditarProductoComponent implements OnInit {
  form: FormGroup;
  constructor(private fb: FormBuilder,private prodService:ProductoService,private router:Router,private rutaActiva: ActivatedRoute) {
    this.form = this.fb.group({
      codProducto:[],
      nombre:['',Validators.required],
      precio:['',Validators.required],
    })
  }

  ngOnInit(): void {
    this.prodService.getProducto(this.rutaActiva.snapshot.params.id).subscribe(resp => {
      this.form.patchValue(resp.message);
    });
  }
  update(){
    const prod: Producto =  {
      codProducto: this.form.value.codProducto,
      nombre: this.form.value.nombre,
      precio: this.form.value.precio
    };
    this.prodService.edit(prod);
    this.router.navigate(['dashboard/producto']);
  }

}
