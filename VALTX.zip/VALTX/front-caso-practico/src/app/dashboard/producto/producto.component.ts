import { Component, OnInit } from '@angular/core';
import {Sucursal} from "../../interfaces/sucursal";
import {SucursalService} from "../../services/sucursal.service";
import {Router} from "@angular/router";
import {Producto} from "../../interfaces/producto";
import {ProductoService} from "../../services/producto.service";

@Component({
  selector: 'app-producto',
  templateUrl: './producto.component.html',
  styleUrls: ['./producto.component.scss']
})
export class ProductoComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name','precio','acciones'];
  listProducto: Producto[] = [];

  totalRecords: number = 0;
  p = 1;
  psize = 2;
  constructor(private prodService:ProductoService,private router: Router) {

  }

  ngOnInit(): void {
    this.getPage(this.p);
  }
  getPage(page: number) {
    this.loadData(page);
  }

  loadData(page: number) {
    //const pageSize = this.psize;
    const pageSize = 30;
    const pageNum = (page - 1) ;
    return this.prodService.list(pageNum, pageSize, '').subscribe((rpt) => {
      this.listProducto = rpt.data;
      this.totalRecords = rpt.total;
      this.p = page;
    });
  }

  delete(id:string){
    this.prodService.delete(id);
    this.getPage(this.p);
  }

  editar(id:string){
    this.router.navigate(['dashboard/editar-producto/'+id])
  }


}
