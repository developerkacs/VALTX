import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {UsuarioService} from "../../services/usuario.service";
import {Usuario} from "../../interfaces/usuario";

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.scss']
})
export class UsuarioComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name','user','pass','sucursal','acciones'];
  listUsuario: Usuario[] = [];

  totalRecords: number = 0;
  p = 1;
  psize = 2;
  constructor(private userService:UsuarioService,private router: Router) {
  }

  ngOnInit(): void {
    this.getPage(this.p);
  }
  getPage(page: number) {
    this.loadData(page);
  }

  loadData(page: number) {
    //const pageSize = this.psize;
    const pageSize = 30;
    const pageNum = (page - 1) ;
    return this.userService.list(pageNum, pageSize, '').subscribe((rpt) => {
      this.listUsuario = rpt.data;
      this.totalRecords = rpt.total;
      this.p = page;
    });
  }

  delete(id:string){
    this.userService.delete(id);
    this.getPage(this.p);
  }

  editar(id:string){
    this.router.navigate(['dashboard/editar-usuario/'+id])
  }

}
