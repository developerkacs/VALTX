import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {UsuarioService} from "../../../services/usuario.service";
import {Usuario} from "../../../interfaces/usuario";
import {Sucursal} from "../../../interfaces/sucursal";
import {SucursalService} from "../../../services/sucursal.service";



@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.component.html',
  styleUrls: ['./crear-usuario.component.scss']
})
export class CrearUsuarioComponent implements OnInit {
  form: FormGroup;

  lstSuc: Sucursal[] = [];

  constructor(private fb: FormBuilder,private userService:UsuarioService,private router:Router,private sucursalService:SucursalService) {
    this.form = this.fb.group({
      codUsuario:[],
      nombre:['',Validators.required],
      user:['',Validators.required],
      password:['',Validators.required],
      codSucursal:['',Validators.required],
    })
  }

  ngOnInit(): void {
    this.loadDataSucursal();
  }

  agregar(){
    const user: Usuario =  {
      codUsuario: this.form.value.codUsuario,
      nombre: this.form.value.nombre,
      user: this.form.value.user,
      password: this.form.value.password,
      codSucursal: this.form.value.codSucursal
    };
    this.userService.save(user);
    this.router.navigate(['dashboard/usuario']);
  }


  loadDataSucursal() {

    return this.sucursalService.listSelect().subscribe((rpt) => {
      this.lstSuc = rpt.data;
    });
  }

}
