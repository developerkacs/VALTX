
export interface Producto {
  codProducto: string;
  nombre: string;
  precio: number;
}
