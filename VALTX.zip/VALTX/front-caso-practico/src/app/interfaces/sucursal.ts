
export interface Sucursal {
  codSucursal: string;
  nombre: string;
}
