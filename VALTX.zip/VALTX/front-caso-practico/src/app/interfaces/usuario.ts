import {Sucursal} from "./sucursal";

export interface Usuario {
  codUsuario: string;
  nombre: string;
  user: string;
  password: string;
  codSucursal: Sucursal
}
