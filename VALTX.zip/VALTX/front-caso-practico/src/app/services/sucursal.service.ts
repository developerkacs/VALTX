import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Sucursal} from "../interfaces/sucursal";

@Injectable({
  providedIn: 'root'
})
export class SucursalService {

  constructor(private http: HttpClient) { }

  save(obj: Sucursal) {
    return this.http.post<any>(`sucursal/save`, obj).subscribe({
      next: data => {
        console.log("save "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }

  list(page: number, psize: number, sortBy: string) {
    return this.http.post<any>(`sucursal/list?pageNum=${page}&pageSize=${psize}`, { });
  }


  listSelect() {
    return this.http.post<any>(`sucursal/list`, { });
  }


  getSucursal(id: string) {
    return this.http.get<any>(`sucursal/${id}`, { });
  }


  edit(obj: Sucursal) {
    return this.http.put<any>(`sucursal/update`, obj).subscribe({
      next: data => {
        console.log("edit "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }

  delete(id: string) {
    return this.http.delete(`sucursal/delete/${id}`).subscribe({
      next: data => {
        console.log("eliminando "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }

}
