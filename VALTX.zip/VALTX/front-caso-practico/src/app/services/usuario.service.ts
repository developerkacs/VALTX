import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Usuario} from "../interfaces/usuario";

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  constructor(private http: HttpClient) { }

  save(obj: Usuario) {
    return this.http.post<any>(`usuario/save`, obj).subscribe({
      next: data => {
        console.log("save "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }

  list(page: number, psize: number, sortBy: string) {
    return this.http.post<any>(`usuario/list?pageNum=${page}&pageSize=${psize}`, { });
  }


  getUsuario(id: string) {
    return this.http.get<any>(`usuario/${id}`, { });
  }


  edit(obj: Usuario) {
    return this.http.put<any>(`usuario/update`, obj).subscribe({
      next: data => {
        console.log("edit "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }

  delete(id: string) {
    return this.http.delete(`usuario/delete/${id}`).subscribe({
      next: data => {
        console.log("eliminando "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }


}
