import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Sucursal} from "../interfaces/sucursal";
import {Producto} from "../interfaces/producto";

@Injectable({
  providedIn: 'root'
})
export class ProductoService {

  constructor(private http: HttpClient) { }

  save(obj: Producto) {
    return this.http.post<any>(`producto/save`, obj).subscribe({
      next: data => {
        console.log("save "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }

  list(page: number, psize: number, sortBy: string) {
    return this.http.post<any>(`producto/list?pageNum=${page}&pageSize=${psize}`, { });
  }


  getProducto(id: string) {
    return this.http.get<any>(`producto/${id}`, { });
  }


  edit(obj: Producto) {
    return this.http.put<any>(`producto/update`, obj).subscribe({
      next: data => {
        console.log("edit "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }

  delete(id: string) {
    return this.http.delete(`producto/delete/${id}`).subscribe({
      next: data => {
        console.log("eliminando "+data)
      },
      error: error => {
        console.error('There was an error!', error);
      }
    });
  }

}
