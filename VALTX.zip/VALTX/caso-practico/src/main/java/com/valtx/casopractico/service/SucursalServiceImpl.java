package com.valtx.casopractico.service;

import com.valtx.casopractico.model.Sucursal;
import com.valtx.casopractico.repo.ISucursalRepo;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@AllArgsConstructor
public class SucursalServiceImpl implements SucursalService{

    @Autowired
    private ISucursalRepo repo;

    @Override
    public Boolean save(Sucursal suc) {
        repo.insert(suc);
        return Boolean.TRUE;
    }

    @Override
    public Boolean update(Sucursal suc) {
        repo.save(suc);
        return Boolean.TRUE;
    }

    @Override
    public Boolean delete(String sucId) {
        repo.deleteById(sucId);
        return Boolean.TRUE;
    }

    @Override
    public Map<String, Object> getAllSucursalInPage(int pageNo, int pageSize, String sortBy, Sucursal suc) {
        Example<Sucursal> example = Example.of(suc);
        Map<String, Object> response = new HashMap<>();

        Sort sort = Sort.by(sortBy);
        Pageable page = PageRequest.of(pageNo, pageSize, sort);
        Page<Sucursal> annPage = repo.findAll(example, page);

        response.put("data", annPage.getContent());
        response.put("tatalPages", annPage.getTotalPages());
        response.put("total", annPage.getTotalElements());
        response.put("page", annPage.getNumber());

        return response;
    }

    @Override
    public Optional<Sucursal> sucursalInfo(String id) {
        return repo.findById(id);
    }
}
