package com.valtx.casopractico.controller;


import com.valtx.casopractico.model.Sucursal;
import com.valtx.casopractico.pojo.GeneralResponse;
import com.valtx.casopractico.service.SucursalService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

@RestController
@AllArgsConstructor
@RequestMapping("/sucursal")
public class SucursalController {

    @Autowired
    private SucursalService sucursalService;


    @PostMapping("/save")
    public ResponseEntity<?> save(@Valid @RequestBody Sucursal suc){
        Boolean status = sucursalService.save(suc);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }

    @PutMapping("/update")
    public ResponseEntity<?> update(@Valid @RequestBody Sucursal suc) {
        Boolean status = sucursalService.update(suc);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }


    @DeleteMapping("/delete/{sucId}")
    public ResponseEntity<?> delete(@PathVariable("sucId") String sucId) {
        Boolean status = sucursalService.delete(sucId);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }


    @GetMapping("/{sucId}")
    public  ResponseEntity<?> info(@PathVariable("sucId") String sucId) {
        Optional<Sucursal> prod = sucursalService.sucursalInfo(sucId);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(prod).timestamp(new Date()).build());
    }

    @PostMapping("/list")
    public Map<String, Object> getAllInPage(
            @RequestParam(name = "pageNum", defaultValue = "0") int pageNo,
            @RequestParam(name = "pageSize", defaultValue = "5") int pageSize,
            @RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
            @RequestBody Sucursal suc
    ) {
        return sucursalService.getAllSucursalInPage(pageNo, pageSize, sortBy, suc);
    }
}
