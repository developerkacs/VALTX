package com.valtx.casopractico.service;

import com.valtx.casopractico.model.Sucursal;

import java.util.Map;
import java.util.Optional;

public interface SucursalService {
    Boolean save(Sucursal suc);
    Boolean update(Sucursal suc);
    Boolean delete(String sucId);
    Map<String, Object> getAllSucursalInPage(int pageNo, int pageSize, String sortBy, Sucursal suc);
    Optional<Sucursal> sucursalInfo(String id);
}
