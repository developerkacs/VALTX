package com.valtx.casopractico.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;

@Document
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Sucursal {
    @Id
    private String codSucursal;
    @NotNull(message = "por favor ingresar nombre de la sucursal")
    private String nombre;
}
