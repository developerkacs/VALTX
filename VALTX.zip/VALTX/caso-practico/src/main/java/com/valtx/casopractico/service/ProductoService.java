package com.valtx.casopractico.service;

import com.valtx.casopractico.model.Producto;

import java.util.Map;
import java.util.Optional;

public interface ProductoService {
    Boolean save(Producto prod);
    Boolean update(Producto prod);
    Boolean delete(String prodId);
    Map<String, Object> getAllProductsInPage(int pageNo, int pageSize, String sortBy, Producto prod);
    Optional<Producto> productInfo(String id);
}
