package com.valtx.casopractico.repo;

import com.valtx.casopractico.model.Usuario;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IUsuarioRepo  extends MongoRepository<Usuario, String> {
}
