package com.valtx.casopractico.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;

@Document
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Producto {
    @Id
    private String codProducto;
    @NotNull(message = "por favor ingresar nombre del producto")
    private String nombre;
    @NotNull(message = "por favor ingresar precio del producto")
    private Double precio;
}
