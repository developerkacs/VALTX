package com.valtx.casopractico.service;

import com.valtx.casopractico.model.Usuario;
import com.valtx.casopractico.repo.IUsuarioRepo;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@AllArgsConstructor
public class UsuarioServiceImpl implements UsuarioService{

    @Autowired
    private IUsuarioRepo repo;

    @Override
    public Boolean save(Usuario user) {
        repo.insert(user);
        return Boolean.TRUE;
    }

    @Override
    public Boolean update(Usuario user) {
        repo.save(user);
        return Boolean.TRUE;
    }

    @Override
    public Boolean delete(String userId) {
        repo.deleteById(userId);
        return Boolean.TRUE;
    }

    @Override
    public Map<String, Object> getAllUserInPage(int pageNo, int pageSize, String sortBy, Usuario user) {
        Example<Usuario>example = Example.of(user);
        Map<String, Object> response = new HashMap<>();

        Sort sort = Sort.by(sortBy);
        Pageable page = PageRequest.of(pageNo, pageSize, sort);
        Page<Usuario> annPage = repo.findAll(example, page);

        response.put("data", annPage.getContent());
        response.put("tatalPages", annPage.getTotalPages());
        response.put("total", annPage.getTotalElements());
        response.put("page", annPage.getNumber());

        return response;
    }

    @Override
    public Optional<Usuario> userInfo(String id) {
        return repo.findById(id);
    }
}
