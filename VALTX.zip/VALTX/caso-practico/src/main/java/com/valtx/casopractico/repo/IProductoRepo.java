package com.valtx.casopractico.repo;

import com.valtx.casopractico.model.Producto;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IProductoRepo  extends MongoRepository<Producto, String> {
}
