package com.valtx.casopractico.service;

import com.valtx.casopractico.model.Usuario;

import java.util.Map;
import java.util.Optional;

public interface UsuarioService {
    Boolean save(Usuario user);
    Boolean update(Usuario user);
    Boolean delete(String userId);
    Map<String, Object> getAllUserInPage(int pageNo, int pageSize, String sortBy, Usuario user);
    Optional<Usuario> userInfo(String id);
}
