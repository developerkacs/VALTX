package com.valtx.casopractico.controller;
import com.valtx.casopractico.model.Producto;
import com.valtx.casopractico.pojo.GeneralResponse;
import com.valtx.casopractico.service.ProductoService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

@RestController
@AllArgsConstructor
@RequestMapping("/producto")
public class ProductoController {

    @Autowired
    private ProductoService productoService;


    @PostMapping("/save")
    public ResponseEntity<?> save(@Valid @RequestBody Producto prod){
        Boolean status = productoService.save(prod);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }

    @PutMapping("/update")
    public ResponseEntity<?> update(@Valid @RequestBody Producto prod) {
        Boolean status = productoService.update(prod);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }


    @DeleteMapping("/delete/{prodId}")
    public ResponseEntity<?> delete(@PathVariable("prodId") String prodId) {
        Boolean status = productoService.delete(prodId);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }


    @GetMapping("/{prodId}")
    public  ResponseEntity<?> info(@PathVariable("prodId") String prodId) {
        Optional<Producto> prod = productoService.productInfo(prodId);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(prod).timestamp(new Date()).build());
    }

    @PostMapping("/list")
    public Map<String, Object> getAllInPage(
            @RequestParam(name = "pageNum", defaultValue = "0") int pageNo,
            @RequestParam(name = "pageSize", defaultValue = "5") int pageSize,
            @RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
            @RequestBody Producto prod
    ) {
        return productoService.getAllProductsInPage(pageNo, pageSize, sortBy, prod);
    }
}
