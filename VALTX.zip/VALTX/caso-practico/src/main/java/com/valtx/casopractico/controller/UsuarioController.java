package com.valtx.casopractico.controller;

import com.valtx.casopractico.model.Usuario;
import com.valtx.casopractico.pojo.GeneralResponse;
import com.valtx.casopractico.service.UsuarioService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.Map;
import java.util.Optional;

@RestController
@AllArgsConstructor
@RequestMapping("/usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;


    @PostMapping("/save")
    public ResponseEntity<?> save(@Valid @RequestBody Usuario user){
        Boolean status = usuarioService.save(user);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }

    @PutMapping("/update")
    public ResponseEntity<?> update(@Valid @RequestBody Usuario user) {
        Boolean status = usuarioService.update(user);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }


    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<?> delete(@PathVariable("userId") String userId) {
        Boolean status = usuarioService.delete(userId);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(status).timestamp(new Date()).build());
    }


    @GetMapping("/{userId}")
    public  ResponseEntity<?> info(@PathVariable("userId") String userId) {
        Optional<Usuario> prod = usuarioService.userInfo(userId);
        return ResponseEntity.ok(GeneralResponse.builder().status(200).message(prod).timestamp(new Date()).build());
    }

    @PostMapping("/list")
    public Map<String, Object> getAllInPage(
            @RequestParam(name = "pageNum", defaultValue = "0") int pageNo,
            @RequestParam(name = "pageSize", defaultValue = "5") int pageSize,
            @RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
            @RequestBody Usuario user
    ) {
        return usuarioService.getAllUserInPage(pageNo, pageSize, sortBy, user);
    }

}
