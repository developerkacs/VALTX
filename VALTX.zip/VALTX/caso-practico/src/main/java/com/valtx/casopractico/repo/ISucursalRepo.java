package com.valtx.casopractico.repo;

import com.valtx.casopractico.model.Sucursal;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ISucursalRepo  extends MongoRepository<Sucursal, String> {

}
