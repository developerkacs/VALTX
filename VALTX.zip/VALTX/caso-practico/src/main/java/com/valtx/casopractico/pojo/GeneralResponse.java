package com.valtx.casopractico.pojo;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class GeneralResponse {
    private static final long serialVersionUID = 1L;
    private Date timestamp;
    private Integer status;
    private Object message;
}
