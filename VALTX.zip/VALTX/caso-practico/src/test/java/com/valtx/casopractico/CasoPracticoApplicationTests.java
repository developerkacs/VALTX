package com.valtx.casopractico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CasoPracticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
